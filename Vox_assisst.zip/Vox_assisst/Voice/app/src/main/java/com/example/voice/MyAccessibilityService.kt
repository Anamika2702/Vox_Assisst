package com.example.voice

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class MyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MyAccessibilityService"
        // Coordinates for the tap (adjust these to the desired location)
        // For example, if the bounds are [156,961][278,1028], the center would be:
        // x = (156 + 278) / 2 = 217, y = (961 + 1028) / 2 = 994.5 ≈ 995
        private const val TAP_X = 217f
        private const val TAP_Y = 995f
        // Delay before performing the tap gesture, in milliseconds
        private const val TAP_DELAY = 4000L
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Process events only from PhonePe
        if (event?.packageName?.toString() == "com.phonepe.app") {
            Handler(Looper.getMainLooper()).postDelayed({
                performTapAtCoordinates(TAP_X, TAP_Y)
            }, TAP_DELAY)
        }
    }

    /**
     * Simulates a tap gesture at the specified (x, y) coordinates.
     */
    private fun performTapAtCoordinates(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(
            GestureDescription.StrokeDescription(path, 0, 100)
        )
        val gesture = gestureBuilder.build()
        val success = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Gesture tap completed")
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Gesture tap cancelled")
            }
        }, null)

        if (!success) {
            Log.d(TAG, "Failed to dispatch gesture")
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "onInterrupt: Service interrupted")
    }
}
