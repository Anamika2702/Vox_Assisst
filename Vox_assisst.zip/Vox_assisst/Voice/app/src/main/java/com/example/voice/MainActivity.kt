package com.example.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.microsoft.onnxruntime.*
import java.util.*
import java.io.File

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var textToSpeech: TextToSpeech
    private lateinit var tvResult: TextView
    private lateinit var onnxSession: InferenceSession

    companion object {
        private const val TAG = "MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvResult = findViewById(R.id.tvResult)
        val btnVoice = findViewById<Button>(R.id.btnVoice)

        // Initialize TextToSpeech
        textToSpeech = TextToSpeech(this, this)

        // Initialize ONNX session with the Whisper model
        try {
            val modelPath = File(getExternalFilesDir(null), "Downloads/whisper_q4_model.bin") // Change path to the exact file location
            val onnxEnv = OnnxRuntimeEnvironment.getEnvironment()
            onnxSession = InferenceSession(modelPath, onnxEnv)
            Log.d(TAG, "Whisper model loaded successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading Whisper model: ${e.message}")
            Toast.makeText(this, "Error loading Whisper model", Toast.LENGTH_SHORT).show()
        }

        // Voice input button click listener
        btnVoice.setOnClickListener {
            tvResult.append("\n🎤 Listening...")
            startListening()
        }
    }

    private fun startListening() {
        // Use Android's default SpeechRecognizer for initial speech input
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        try {
            val speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val spokenText = matches[0]
                        tvResult.append("\n🔊 $spokenText")

                        // Process the spoken text using Whisper Q4
                        val transcript = transcribeWithWhisper(spokenText)
                        tvResult.append("\n📝 Transcription: $transcript")
                        handleConversation(transcript)
                    }
                }

                override fun onError(error: Int) {
                    Log.e(TAG, "Error with speech recognition: $error")
                    tvResult.append("\nError occurred: $error")
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onEndOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognizer: ${e.message}")
            Toast.makeText(this, "Error starting speech recognizer", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to transcribe speech using Whisper model
    private fun transcribeWithWhisper(spokenText: String): String {
        return try {
            // Preprocess input, convert to suitable format
            val inputTensor = OnnxTensor.createTensor(onnxSession.environment, spokenText)

            // Run inference
            val results = onnxSession.run(Collections.singletonList(inputTensor))

            // Postprocess the results (example: convert tensor output to readable text)
            val outputTensor = results[0]
            val transcript = outputTensor.stringValue().trim()
            Log.d(TAG, "Whisper transcription result: $transcript")
            transcript
        } catch (e: Exception) {
            Log.e(TAG, "Error during Whisper inference: ${e.message}")
            "Error transcribing speech"
        }
    }

    // Handle conversation states
    private fun handleConversation(transcript: String) {
        Log.d(TAG, "Handling conversation: $transcript")
        // Example: Process transcription for specific commands
        if (transcript.contains("send money", ignoreCase = true)) {
            speakResponse("Who do you want to send money to?")
        }
    }

    // TTS callback methods
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val langResult = textToSpeech.setLanguage(Locale.getDefault())
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "Language not supported or missing data", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun speakResponse(response: String) {
        textToSpeech.speak(response, TextToSpeech.QUEUE_FLUSH, null, "utteranceId")
    }

    override fun onDestroy() {
        textToSpeech.stop()
        textToSpeech.shutdown()
        onnxSession.close()
        super.onDestroy()
    }
}
